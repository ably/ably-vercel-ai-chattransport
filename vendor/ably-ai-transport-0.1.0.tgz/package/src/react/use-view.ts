/**
 * useView — reactive paginated view of the conversation.
 *
 * Subscribes to view updates and exposes the visible messages, msg-anchored
 * branch navigation, write operations, pagination state, and a `loadOlder`
 * callback. Pass `session` to use a session's default view, or `view` to
 * subscribe to a specific {@link View} directly. When both are omitted,
 * defaults to the nearest {@link ClientSessionProvider}'s session via context.
 */

import * as Ably from 'ably';
import { useCallback, useEffect, useRef, useState } from 'react';

import type { CodecInputEvent, CodecOutputEvent } from '../core/codec/types.js';
import type { ActiveRun, BranchSelection, RunInfo, SendOptions, View } from '../core/transport/types.js';
import { ErrorCode } from '../errors.js';
import type { BaseSessionOption } from './internal/use-resolved-session.js';
import { useResolvedSession } from './internal/use-resolved-session.js';

/** Options for {@link useView}. */
export interface UseViewOptions<
  TInput extends CodecInputEvent,
  TOutput extends CodecOutputEvent,
  TProjection,
  TMessage,
> extends BaseSessionOption<TInput, TOutput, TProjection, TMessage> {
  /** A specific {@link View} to subscribe to directly. Takes priority over `session`. */
  view?: View<TInput, TMessage> | null;
  /** Maximum number of older messages to load per page. When provided, auto-loads on mount. */
  limit?: number;
  /** When `true`, skip all subscriptions and return an empty handle immediately. */
  skip?: boolean;
}

/** Handle for the paginated, branch-aware conversation view. */
export interface ViewHandle<TInput extends CodecInputEvent, TMessage> {
  /**
   * The visible domain messages along the selected branch, concatenated
   * across all visible Runs.
   */
  messages: TMessage[];
  /** Whether there are older messages that can be revealed via `loadOlder`. */
  hasOlder: boolean;
  /** Whether a page load is currently in progress. */
  loading: boolean;
  /**
   * Set when the most recent `loadOlder` call failed.
   * Cleared automatically on the next successful load.
   * `undefined` when no error has occurred or when `skip` is `true`.
   */
  loadError: Ably.ErrorInfo | undefined;
  /**
   * Load older messages into the view. No-op if already loading.
   * On failure, `error` is set; on success, `error` is cleared.
   */
  loadOlder: () => Promise<void>;
  /**
   * Look up the {@link RunInfo} for the Run that owns `codecMessageId`.
   * Returns `undefined` when the codec-message-id hasn't been observed.
   * See {@link View.runOf}.
   */
  runOf: (codecMessageId: string) => RunInfo | undefined;
  /**
   * Direct lookup by runId. Returns `undefined` when the Run hasn't been
   * observed. See {@link View.run}.
   */
  run: (runId: string) => RunInfo | undefined;
  /**
   * Resolve the {@link BranchSelection} bundle anchored at
   * `codecMessageId`. Always returns a safe object — see
   * {@link BranchSelection}. See {@link View.branchSelection}.
   */
  branchSelection: (codecMessageId: string) => BranchSelection<TMessage>;
  /**
   * Select a sibling at the branch point anchored at `codecMessageId`.
   * `index` is clamped to `[0, siblings.length - 1]`. Silent no-op when
   * `codecMessageId` isn't a branch anchor. See {@link View.selectSibling}.
   */
  selectSibling: (codecMessageId: string, index: number) => void;
  /** Send one or more user messages on the channel and fire a POST. See {@link View.sendMessage}. */
  sendMessage: (messages: TMessage | TMessage[], options?: SendOptions) => Promise<ActiveRun>;
  /** Send one or more TInputs on the channel and fire a POST. See {@link View.sendInput}. */
  sendInput: (events: TInput | TInput[], options?: SendOptions) => Promise<ActiveRun>;
  /** Regenerate an assistant message, using this view's branch for history. */
  regenerate: (messageId: string, options?: SendOptions) => Promise<ActiveRun>;
  /** Edit a user message, forking from this view's branch. */
  edit: (messageId: string, inputs: TInput | TInput[], options?: SendOptions) => Promise<ActiveRun>;
}

/**
 * Fallback returned by `branchSelection` when the view isn't resolved.
 * Same shape the view returns for an unknown codec-message-id, so callers
 * can destructure uniformly.
 */
const EMPTY_BRANCH_SELECTION: BranchSelection<never> = {
  hasSiblings: false,
  siblings: [],
  index: 0,
  selected: undefined,
};

/**
 * Subscribe to a view and return the visible messages with pagination, navigation, and write operations.
 *
 * `view` takes priority over `session`. When neither is provided, the nearest
 * {@link ClientSessionProvider}'s session is used. When `limit` is provided, auto-loads
 * the first page on mount (SWR-style).
 * @param props - Options for selecting the view source and configuring auto-load.
 * @param props.session - Client session whose default view to subscribe to; defaults to the nearest provider.
 * @param props.view - A specific {@link View} to subscribe to directly. Takes priority over `session`.
 * @param props.limit - Max older messages per page; when provided, auto-loads on mount.
 * @param props.skip - When `true`, skip all subscriptions and return an empty handle.
 * @returns A {@link ViewHandle} with messages, pagination state, navigation, write operations, and loadOlder.
 */
export const useView = <TInput extends CodecInputEvent, TOutput extends CodecOutputEvent, TProjection, TMessage>({
  session,
  view,
  limit,
  skip,
}: UseViewOptions<TInput, TOutput, TProjection, TMessage> = {}): ViewHandle<TInput, TMessage> => {
  const resolvedSession = useResolvedSession({ session, skip });
  const resolvedView = skip ? undefined : (view ?? resolvedSession?.view);

  const [messages, setMessages] = useState<TMessage[]>(() => resolvedView?.getMessages() ?? []);
  const [hasOlder, setHasOlder] = useState(() => resolvedView?.hasOlder() ?? false);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState<Ably.ErrorInfo | undefined>();
  const loadingRef = useRef(false);

  // Auto-load first page on mount when limit is provided (SWR-style).
  // Fires once per view instance — subsequent changes to limit
  // only affect manual loadOlder() calls, not the initial auto-load.
  const autoLoad = limit !== undefined;
  const autoLoadedRef = useRef(false);

  // Subscribe to view updates
  useEffect(() => {
    if (!resolvedView) {
      setMessages([]);
      setHasOlder(false);
      setLoadError(undefined);
      return;
    }

    // Reset auto-load flag so the new view gets its first page loaded
    autoLoadedRef.current = false;

    // Sync initial state
    setMessages(resolvedView.getMessages());
    setHasOlder(resolvedView.hasOlder());
    setLoadError(undefined);

    const unsub = resolvedView.on('update', () => {
      setMessages(resolvedView.getMessages());
      setHasOlder(resolvedView.hasOlder());
    });
    return unsub;
  }, [resolvedView]);

  const loadOlder = useCallback(async () => {
    if (!resolvedView || loadingRef.current) return;
    loadingRef.current = true;
    setLoading(true);
    try {
      await resolvedView.loadOlder(limit);
      setLoadError(undefined);
    } catch (error) {
      if (error instanceof Ably.ErrorInfo) {
        setLoadError(error);
      } else {
        setLoadError(new Ably.ErrorInfo('Unknown error loading older messages', ErrorCode.BadRequest, 400));
      }
    } finally {
      loadingRef.current = false;
      setLoading(false);
    }
  }, [resolvedView, limit]);

  useEffect(() => {
    if (!autoLoad || autoLoadedRef.current || !resolvedView) return;
    autoLoadedRef.current = true;
    void loadOlder();
  }, [autoLoad, resolvedView, loadOlder]);

  // Run lookups
  const runOf = useCallback(
    (codecMessageId: string): RunInfo | undefined => resolvedView?.runOf(codecMessageId),
    [resolvedView],
  );

  const run = useCallback((runId: string): RunInfo | undefined => resolvedView?.run(runId), [resolvedView]);

  // Branch navigation
  const branchSelection = useCallback(
    (codecMessageId: string): BranchSelection<TMessage> =>
      // CAST: `EMPTY_BRANCH_SELECTION` is typed `BranchSelection<never>`; `never` is
      // assignable to any `TMessage`, so the empty bundle is a valid fallback for
      // the not-yet-resolved view case.
      resolvedView?.branchSelection(codecMessageId) ?? (EMPTY_BRANCH_SELECTION as BranchSelection<TMessage>),
    [resolvedView],
  );

  const selectSibling = useCallback(
    (codecMessageId: string, index: number) => {
      resolvedView?.selectSibling(codecMessageId, index);
    },
    [resolvedView],
  );

  // Write operation callbacks
  const sendMessage = useCallback(
    async (msgs: TMessage | TMessage[], opts?: SendOptions) => {
      if (!resolvedView)
        throw new Ably.ErrorInfo('unable to send; view is not available', ErrorCode.InvalidArgument, 400);
      return resolvedView.sendMessage(msgs, opts);
    },
    [resolvedView],
  );

  const sendInput = useCallback(
    async (events: TInput | TInput[], opts?: SendOptions) => {
      if (!resolvedView)
        throw new Ably.ErrorInfo('unable to send; view is not available', ErrorCode.InvalidArgument, 400);
      return resolvedView.sendInput(events, opts);
    },
    [resolvedView],
  );

  const regenerate = useCallback(
    async (messageId: string, opts?: SendOptions) => {
      if (!resolvedView)
        throw new Ably.ErrorInfo('unable to regenerate; view is not available', ErrorCode.InvalidArgument, 400);
      return resolvedView.regenerate(messageId, opts);
    },
    [resolvedView],
  );

  const edit = useCallback(
    async (messageId: string, inputs: TInput | TInput[], opts?: SendOptions) => {
      if (!resolvedView)
        throw new Ably.ErrorInfo('unable to edit; view is not available', ErrorCode.InvalidArgument, 400);
      return resolvedView.edit(messageId, inputs, opts);
    },
    [resolvedView],
  );

  return {
    messages,
    hasOlder,
    loading,
    loadError,
    loadOlder,
    runOf,
    run,
    branchSelection,
    selectSibling,
    sendMessage,
    sendInput,
    regenerate,
    edit,
  };
};
